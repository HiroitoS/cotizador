from reportlab.lib.pagesizes import A4, landscape
from reportlab.pdfgen import canvas
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import Table, TableStyle, SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
import os
from django.conf import settings

LOGO_PATH = os.path.join(settings.BASE_DIR, "cotizador_colegio", "static", "img", "book_express.jpg")

styles = getSampleStyleSheet()
H1 = styles["Heading1"]
H2 = styles["Heading2"]
N  = styles["Normal"]

def _header_story(cot):
    data_empresa = [
        [Paragraph("<b>BOOK EXPRESS</b>", H2), ""]
    ]
    t = Table(data_empresa, colWidths=[12*cm, 12*cm])
    t.setStyle(TableStyle([
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
    ]))

    info = []
    info.append(t)
    info.append(Spacer(1, 4))
    info.append(Paragraph(f"<b>Cotización:</b> {cot.numero_cotizacion}", N))
    info.append(Paragraph(f"<b>Colegio:</b> {cot.institucion.nombre}", N))
    info.append(Paragraph(f"<b>Asesor:</b> {cot.asesor.nombre}", N))
    info.append(Paragraph(f"<b>Fecha:</b> {cot.fecha.strftime('%d/%m/%Y')}", N))
    info.append(Spacer(1, 10))
    return info

def _draw_logo(canv):
    if os.path.exists(LOGO_PATH):
        try:
            canv.drawImage(LOGO_PATH, 1*cm, 18*cm, width=3.2*cm, height=3.2*cm, preserveAspectRatio=True, mask='auto')
        except:
            pass

def generar_pdf_cotizacion(cot, response):
    doc = SimpleDocTemplate(response, pagesize=landscape(A4), leftMargin=1.2*cm, rightMargin=1.2*cm, topMargin=1.0*cm, bottomMargin=1.0*cm)
    story = []

    story += _header_story(cot)
    story.append(Paragraph("<b>Detalle de Cotización</b>", H2))
    story.append(Spacer(1, 6))

    # Encabezado de tabla dinámico según tipo_venta del primer detalle
    detalles = cot.detalles.select_related("libro").all()
    tipo = detalles.first().tipo_venta if detalles else "PV"

    headers = ["Editorial","Nivel","Grado","Área","Descripción","PVP","P.Prov."]
    if tipo in ("PV","FERIA"):
        headers += ["P. IE","P. PPFF","Utilidad IE","ROI IE"]
    else:
        headers += ["% Desc","Comisión","P. Consigna","P. Coordinado","Utilidad","ROI Cons."]

    data = [headers]

    for d in detalles:
        base = [
            d.libro.empresa, d.libro.nivel, d.libro.grado, d.libro.area,
            d.libro.descripcion_completa,
            f"{(d.precio_be or 0):.2f}",
            # precio proveedor = PVP - (PVP * desc_proveedor%)
            f"{((d.precio_be or 0) - ((d.precio_be or 0) * (float(d.desc_proveedor or 0)/100))):.2f}"
        ]

        if d.tipo_venta in ("PV","FERIA"):
            utilidad = (d.precio_ppff or 0) - (d.precio_ie or 0)
            roi = (d.precio_ie or 0) - ((d.precio_be or 0) - ((d.precio_be or 0)*(float(d.desc_proveedor or 0)/100)))
            base += [
                f"{(d.precio_ie or 0):.2f}",
                f"{(d.precio_ppff or 0):.2f}",
                f"{utilidad:.2f}",
                f"{roi:.2f}",
            ]
        else:
            precio_consigna = (d.precio_be or 0) - ((d.precio_be or 0)*(float(d.desc_consigna or 0)/100))
            precio_coordinado = precio_consigna - float(d.comision or 0)
            utilidad = (d.precio_be or 0) - precio_consigna
            precio_proveedor = (d.precio_be or 0) - ((d.precio_be or 0)*(float(d.desc_proveedor or 0)/100))
            roi = precio_coordinado - precio_proveedor

            base += [
                f"{float(d.desc_consigna or 0):.2f}",
                f"{float(d.comision or 0):.2f}",
                f"{precio_consigna:.2f}",
                f"{precio_coordinado:.2f}",
                f"{utilidad:.2f}",
                f"{roi:.2f}",
            ]

        data.append(base)

    table = Table(data, repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.black),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
        ("ALIGN", (5,0), (-1,-1), "RIGHT"),
        ("GRID", (0,0), (-1,-1), 0.5, colors.grey),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.whitesmoke, colors.lightgrey]),
        ("FONTSIZE", (0,0), (-1,-1), 8),
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
    ]))
    story.append(table)

    def first_page(canv, doc):
        _draw_logo(canv)

    doc.build(story, onFirstPage=first_page, onLaterPages=first_page)


def generar_pdf_adopcion(adop, response):
    cot = adop.cotizacion
    doc = SimpleDocTemplate(response, pagesize=landscape(A4), leftMargin=1.2*cm, rightMargin=1.2*cm, topMargin=1.0*cm, bottomMargin=1.0*cm)
    story = []

    story += _header_story(cot)
    story.append(Paragraph("<b>Ficha de Adopción</b>", H2))
    story.append(Spacer(1, 6))

    data = [["Libro","Editorial","Nivel","Grado","Área","Cantidad","Mes Lectura"]]

    for d in adop.detalles.select_related("libro").all():
        data.append([
            d.libro.descripcion_completa,
            d.libro.empresa, d.libro.nivel, d.libro.grado, d.libro.area,
            str(d.cantidad_adoptada or ""),
            d.mes_lectura or "—",
        ])

    table = Table(data, repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.black),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
        ("ALIGN", (5,0), (-1,-1), "CENTER"),
        ("GRID", (0,0), (-1,-1), 0.5, colors.grey),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.whitesmoke, colors.lightgrey]),
        ("FONTSIZE", (0,0), (-1,-1), 8),
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
    ]))
    story.append(table)

    # Bloque de firmas (Director + Asesor)
    story.append(Spacer(1, 18))
    story.append(Paragraph("<b>Directivo de la I.E.</b>", N))
    story.append(Spacer(1, 30))
    story.append(Paragraph("_____________________________", N))
    story.append(Paragraph("Sello y Firma", N))
    story.append(Spacer(1, 16))
    story.append(Paragraph(f"<b>Asesor Comercial:</b> {cot.asesor.nombre}", N))
    story.append(Paragraph("Dirección: Jr. Omar Yali 371 - Huancayo", N))
    story.append(Paragraph("Teléfono: 934941161", N))
    story.append(Paragraph("Email: contacto@book-express.com", N))

    def first_page(canv, doc):
        _draw_logo(canv)

    doc.build(story, onFirstPage=first_page, onLaterPages=first_page)
