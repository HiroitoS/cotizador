from rest_framework import serializers
from .models import (
    Libro, InstitucionEducativa, AsesorComercial,
    Cotizacion, DetalleCotizacion,
    Adopcion, DetalleAdopcion,
    Pedido, DetallePedido
)

# -----------------------------
# Libros / Personas / Colegios
# -----------------------------
class LibroSerializer(serializers.ModelSerializer):
    class Meta:
        model = Libro
        fields = [
            "id", "empresa", "nivel", "grado", "area",
            "serie", "descripcion_completa",
            "tipo_inventario", "soporte", "pvp_2026_con_igv",
        ]

class InstitucionSerializer(serializers.ModelSerializer):
    class Meta:
        model = InstitucionEducativa
        fields = "__all__"

class AsesorSerializer(serializers.ModelSerializer):
    class Meta:
        model = AsesorComercial
        fields = "__all__"

# -----------------------------
# Cotización (panel / detalle)
# -----------------------------
class DetalleCotizacionSerializer(serializers.ModelSerializer):
    # Para listados internos
    libro_nombre = serializers.CharField(source="libro.descripcion_completa", read_only=True)
    editorial = serializers.CharField(source="libro.empresa", read_only=True)
    nivel = serializers.CharField(source="libro.nivel", read_only=True)  # ⚠️ campo correcto en Libro
    grado = serializers.CharField(source="libro.grado", read_only=True)
    area = serializers.CharField(source="libro.area", read_only=True)

    class Meta:
        model = DetalleCotizacion
        fields = "__all__"

class CotizacionSerializer(serializers.ModelSerializer):
    # Para el panel de cotizaciones (lo que ve tu tabla)
    institucion = serializers.CharField(source="institucion.nombre", read_only=True)
    asesor = serializers.CharField(source="asesor.nombre", read_only=True)

    class Meta:
        model = Cotizacion
        fields = ["id", "numero_cotizacion", "institucion", "asesor", "fecha", "estado"]

# Para el modal de adopción: necesitamos cada detalle con el libro resumido
class LibroSimpleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Libro
        fields = ["empresa", "nivel", "grado", "area", "descripcion_completa"]

class DetalleCotizacionSimpleSerializer(serializers.ModelSerializer):
    libro = LibroSimpleSerializer(read_only=True)

    class Meta:
        model = DetalleCotizacion
        fields = ["id", "libro"]

class CotizacionDetalleSerializer(serializers.ModelSerializer):
    institucion = serializers.CharField(source="institucion.nombre", read_only=True)
    asesor = serializers.CharField(source="asesor.nombre", read_only=True)
    detalles = DetalleCotizacionSimpleSerializer(many=True, read_only=True)

    class Meta:
        model = Cotizacion
        fields = ["id", "numero_cotizacion", "tipo_venta", "institucion", "asesor", "fecha", "detalles"]

# -----------------------------
# Adopción
# -----------------------------
class DetalleAdopcionSerializer(serializers.ModelSerializer):
    libro = LibroSerializer(read_only=True)

    class Meta:
        model = DetalleAdopcion
        exclude = ["adopcion"]

class AdopcionSerializer(serializers.ModelSerializer):
    cotizacion = serializers.PrimaryKeyRelatedField(read_only=True)
    detalles = DetalleAdopcionSerializer(many=True, read_only=True)

    class Meta:
        model = Adopcion
        fields = "__all__"

# -----------------------------
# Pedido
# -----------------------------
class DetallePedidoSerializer(serializers.ModelSerializer):
    libro = LibroSerializer(read_only=True)

    class Meta:
        model = DetallePedido
        exclude = ["pedido"]

class PedidoSerializer(serializers.ModelSerializer):
    adopcion = serializers.PrimaryKeyRelatedField(read_only=True)
    detalles = DetallePedidoSerializer(many=True, read_only=True)

    class Meta:
        model = Pedido
        fields = "__all__"
