from decimal import Decimal
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from django.db.models.functions import Lower
from django_filters.rest_framework import DjangoFilterBackend

from rest_framework import status, generics, filters
from rest_framework.generics import ListAPIView
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.decorators import api_view

from .models import (
    Cotizacion, Libro, Adopcion, Pedido,
    AsesorComercial, InstitucionEducativa,
    DetalleCotizacion, DetalleAdopcion
)
from .serializers import (
    CotizacionSerializer, LibroSerializer,
    PedidoSerializer, AsesorSerializer, InstitucionSerializer,
)

# PDFs
from .services_pdf import generar_pdf_cotizacion, generar_pdf_adopcion


# ------------------------------------
# 1) LIBROS con filtros/búsqueda
# ------------------------------------
class ListarLibrosView(generics.ListAPIView):
    queryset = Libro.objects.all().order_by("empresa", "nivel", "grado", "area")
    serializer_class = LibroSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ["nivel", "area", "grado", "empresa"]
    search_fields = ["descripcion_completa", "serie", "empresa"]


# ------------------------------------
# 2) GUARDAR COTIZACIÓN
# ------------------------------------
class GuardarCotizacionView(APIView):
    def post(self, request):
        data = request.data
        institucion = data.get("institucion") or {}
        asesor = data.get("asesor") or {}
        detalles = data.get("detalles") or []

        if not institucion.get("id"):
            return Response({"detail": "Falta institución."}, status=400)
        if not asesor.get("id"):
            return Response({"detail": "Falta asesor."}, status=400)
        if not isinstance(detalles, list) or not detalles:
            return Response({"detail": "Faltan detalles."}, status=400)

        cot = Cotizacion.objects.create(
            institucion_id=institucion["id"],
            asesor_id=asesor["id"]
        )

        for det in detalles:
            DetalleCotizacion.objects.create(
                cotizacion=cot,
                libro_id=det["libro_id"],
                tipo_venta=det["tipo_venta"],
                precio_be=det.get("precio_be"),
                desc_proveedor=det.get("desc_proveedor"),
                precio_ie=det.get("precio_ie"),
                precio_ppff=det.get("precio_ppff"),
                desc_consigna=det.get("desc_consigna"),
                comision=det.get("comision"),
            )

        return Response({"numero": cot.numero_cotizacion}, status=201)


# ------------------------------------
# 3) LISTAR COTIZACIONES (panel)
# ------------------------------------
class ListarCotizacionesView(APIView):
    def get(self, request):
        cotizaciones = Cotizacion.objects.select_related("institucion", "asesor").order_by("-fecha")
        data = CotizacionSerializer(cotizaciones, many=True).data
        return Response(data, status=200)


# ------------------------------------
# 4) CAMBIAR ESTADO (PENDIENTE -> APROBADA/RECHAZADA)
# ------------------------------------
class CambiarEstadoCotizacionView(APIView):
    def patch(self, request, pk):
        cot = get_object_or_404(Cotizacion, pk=pk)
        estado = request.data.get("estado")
        if estado not in ["APROBADA", "RECHAZADA"]:
            return Response({"detail": "Estado no válido."}, status=400)
        cot.estado = estado
        cot.save(update_fields=["estado"])
        return Response({"message": "Estado actualizado"}, status=200)


# ------------------------------------
# 5) CALCULAR DETALLE (preview en tiempo real)
# ------------------------------------
class CalcularDetalleView(APIView):
    def post(self, request, *args, **kwargs):
        data = request.data or {}
        libro_id = data.get("libro") or data.get("id")
        tipo_venta = data.get("tipo_venta")

        if not libro_id or not tipo_venta:
            return Response({"detail": "Campos requeridos: libro, tipo_venta."}, status=400)

        libro = get_object_or_404(Libro, pk=libro_id)

        try:
            precio_be = float(data.get("precio_be", libro.pvp_2026_con_igv or 0))
            desc_proveedor = float(data.get("desc_proveedor", 0))
        except (TypeError, ValueError):
            return Response({"detail": "precio_be/desc_proveedor inválidos."}, status=400)

        precio_proveedor = round(precio_be - (precio_be * (desc_proveedor / 100.0)), 2)

        resp = {
            "id": libro.id,
            "precio_be": round(precio_be, 2),
            "desc_proveedor": round(desc_proveedor, 2),
            "precio_proveedor": precio_proveedor,
        }

        if tipo_venta in ("PV", "FERIA"):
            try:
                precio_ie = float(data.get("precio_ie", 0))
                precio_ppff = float(data.get("precio_ppff", 0))
            except (TypeError, ValueError):
                return Response({"detail": "precio_ie/precio_ppff inválidos."}, status=400)

            if precio_ie < 0 or precio_ppff < 0:
                return Response({"detail": "Precios no pueden ser negativos."}, status=400)

            utilidad_ie = round(precio_ppff - precio_ie, 2)
            roi_ie = round(precio_ie - precio_proveedor, 2)

            resp.update({
                "tipo_venta": tipo_venta,
                "precio_ie": precio_ie,
                "precio_ppff": precio_ppff,
                "utilidad_ie": utilidad_ie,
                "roi_ie": roi_ie,
                "desc_consigna": None, "comision": None,
                "precio_consigna": None, "precio_coordinado": None,
                "roi_consigna": None,
            })
            return Response(resp, status=200)

        elif tipo_venta == "CONSIGNA":
            try:
                desc_consigna = float(data.get("desc_consigna", 0))   # %
                comision = float(data.get("comision", 0))             # monto
            except (TypeError, ValueError):
                return Response({"detail": "desc_consigna/comision inválidos."}, status=400)

            if desc_consigna > 20:
                return Response({"detail": "El descuento de consignación no puede superar 20%."}, status=400)

            precio_consigna = round(precio_be - (precio_be * (desc_consigna / 100.0)), 2)
            precio_coordinado = round(precio_consigna - comision, 2)
            utilidad_ie = round(precio_be - precio_consigna, 2)
            roi_consigna = round(precio_coordinado - precio_proveedor, 2)

            resp.update({
                "tipo_venta": tipo_venta,
                "desc_consigna": round(desc_consigna, 2),
                "comision": round(comision, 2),
                "precio_consigna": precio_consigna,
                "precio_coordinado": precio_coordinado,
                "utilidad_ie": utilidad_ie,
                "roi_consigna": roi_consigna,
                "precio_ie": None, "precio_ppff": None, "roi_ie": None,
            })
            return Response(resp, status=200)

        return Response({"detail": "tipo_venta inválido."}, status=400)


# ------------------------------------
# 6) DETALLE de cotización (para Modal Adopción)
# ------------------------------------
class DetalleCotizacionRetrieveView(APIView):
    def get(self, request, pk):
        cot = get_object_or_404(Cotizacion, pk=pk)
        detalles = cot.detalles.all()

        data = {
            "id": cot.id,
            "numero_cotizacion": cot.numero_cotizacion,
            "institucion": cot.institucion.nombre,
            "asesor": cot.asesor.nombre,
            "fecha": cot.fecha,
            "tipo_venta": detalles.first().tipo_venta if detalles else None,
            "detalles": []
        }

        for d in detalles:
            area = d.libro.area or ""
            data["detalles"].append({
                "id": d.id,
                "libro": {
                    "descripcion_completa": d.libro.descripcion_completa,
                    "empresa": d.libro.empresa,
                    "nivel": d.libro.nivel,
                    "grado": d.libro.grado,
                    "area": d.libro.area,
                },
                "es_plan_lector": "lector" in area.lower(),
                "cantidad": d.cantidad,
                "mes_lectura": None,
                "libro_id": d.libro.id
            })

        return Response(data, status=200)


# ------------------------------------
# 7) Crear Adopción con cantidades (+ mes si plan lector)
# ------------------------------------
class CrearAdopcionView(APIView):
    def post(self, request):
        cotizacion_id = request.data.get("cotizacion_id")
        items = request.data.get("items") or []
        if not cotizacion_id or not items:
            return Response({"detail": "cotizacion_id e items son requeridos."}, status=400)

        cot = get_object_or_404(Cotizacion, pk=cotizacion_id)
        adop, _ = Adopcion.objects.get_or_create(cotizacion=cot)
        adop.detalles.all().delete()

        for it in items:
            det_id = it.get("detalle_id")
            cant = it.get("cantidad")
            mes = it.get("mes_lectura")
            if not det_id or not cant:
                return Response({"detail": "Cada item requiere detalle_id y cantidad > 0."}, status=400)

            det_cot = get_object_or_404(
                DetalleCotizacion.objects.select_related("libro"),
                pk=det_id, cotizacion=cot
            )
            DetalleAdopcion.objects.create(
                adopcion=adop,
                libro=det_cot.libro,
                cantidad_adoptada=int(cant),
                mes_lectura=mes
            )

        if cot.estado != "ADOPTADA":
            cot.estado = "ADOPTADA"
            cot.save(update_fields=["estado"])

        return Response({"adopcion_id": adop.id}, status=201)


# ------------------------------------
# 8) PEDIDOS (listado)
# ------------------------------------
class ListarPedidosView(generics.ListAPIView):
    queryset = Pedido.objects.select_related("adopcion", "adopcion__cotizacion").order_by("-fecha_pedido")
    serializer_class = PedidoSerializer


# ------------------------------------
# 9) Filtros de catálogos para el front
# ------------------------------------
@api_view(["GET"])
def filtros_libros(request):
    data = {
        "empresas": list(
            Libro.objects.exclude(empresa__isnull=True)
            .exclude(empresa__exact="")
            .values_list("empresa", flat=True)
            .distinct()
            .order_by(Lower("empresa"))
        ),
        "niveles": list(
            Libro.objects.exclude(nivel__isnull=True)
            .exclude(nivel__exact="")
            .values_list("nivel", flat=True)
            .distinct()
            .order_by(Lower("nivel"))
        ),
        "areas": list(
            Libro.objects.exclude(area__isnull=True)
            .exclude(area__exact="")
            .values_list("area", flat=True)
            .distinct()
            .order_by(Lower("area"))
        ),
        "grados": list(
            Libro.objects.exclude(grado__isnull=True)
            .exclude(grado__exact="")
            .values_list("grado", flat=True)
            .distinct()
            .order_by(Lower("grado"))
        ),
    }
    return Response(data)


# ------------------------------------
# 10) Asesores / Instituciones
# ------------------------------------
class ListarAsesoresView(ListAPIView):
    queryset = AsesorComercial.objects.filter(estado="ACTIVO").order_by("nombre")
    serializer_class = AsesorSerializer

class ListarColegiosView(ListAPIView):
    queryset = InstitucionEducativa.objects.all().order_by("nombre")
    serializer_class = InstitucionSerializer


# ------------------------------------
# 11) PDFs (Cotización / Adopción)
# ------------------------------------
class PDFCotizacionView(APIView):
    def get(self, request, pk):
        cot = get_object_or_404(Cotizacion, pk=pk)
        response = HttpResponse(content_type="application/pdf")
        response['Content-Disposition'] = f'attachment; filename="Cotizacion_{cot.numero_cotizacion}.pdf"'
        generar_pdf_cotizacion(cot, response)
        return response

class PDFAdopcionView(APIView):
    def get(self, request, pk):
        adop = get_object_or_404(Adopcion, cotizacion_id=pk)
        response = HttpResponse(content_type="application/pdf")
        response['Content-Disposition'] = f'attachment; filename="Adopcion_{adop.cotizacion.numero_cotizacion}.pdf"'
        generar_pdf_adopcion(adop, response)
        return response
