from django.urls import path
from .views import (
    ListarLibrosView,
    GuardarCotizacionView,
    ListarCotizacionesView,
    CambiarEstadoCotizacionView,
    CalcularDetalleView,
    DetalleCotizacionRetrieveView,
    CrearAdopcionView,
    ListarPedidosView,
    filtros_libros,
    ListarAsesoresView,
    ListarColegiosView,
    PDFCotizacionView,
    PDFAdopcionView,
)

urlpatterns = [
    # Libros y filtros
    path("libros/", ListarLibrosView.as_view(), name="listar_libros"),
    path("libros/filtros/", filtros_libros, name="filtros_libros"),

    # Cotizaciones
    path("cotizaciones/guardar/", GuardarCotizacionView.as_view(), name="guardar_cotizacion"),
    path("cotizaciones/listar/", ListarCotizacionesView.as_view(), name="listar_cotizaciones"),
    path("cotizaciones/<int:pk>/", DetalleCotizacionRetrieveView.as_view(), name="detalle_cotizacion"),
    path("cotizaciones/estado/<int:pk>/", CambiarEstadoCotizacionView.as_view(), name="cambiar_estado_cotizacion"),
    path("cotizaciones/calcular_detalle/", CalcularDetalleView.as_view(), name="calcular_detalle"),
    path("cotizaciones/<int:pk>/pdf/", PDFCotizacionView.as_view(), name="pdf_cotizacion"),

    # Adopciones
    path("adopciones/crear/", CrearAdopcionView.as_view(), name="crear_adopcion"),
    path("adopciones/<int:pk>/pdf/", PDFAdopcionView.as_view(), name="pdf_adopcion"),

    # Pedidos
    path("pedidos/listar/", ListarPedidosView.as_view(), name="listar_pedidos"),

    # Asesores / Instituciones
    path("asesores/", ListarAsesoresView.as_view(), name="listar_asesores"),
    path("instituciones/", ListarColegiosView.as_view(), name="listar_instituciones"),
]
