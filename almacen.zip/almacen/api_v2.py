from django.db import transaction
from django.db.models import Q
from django.db import models


from rest_framework import viewsets, mixins
from rest_framework.decorators import action
from rest_framework.pagination import PageNumberPagination
from rest_framework.response import Response

from .models import (
    Almacen,
    Ingreso,
    Transferencia,
    Stock,
    MovimientoStock,
    EstadoTransferencia,
)

from .serializers import (
    AlmacenSerializer,
    IngresoWriteSerializer,
    IngresoReadSerializer,
    TransferenciaWriteSerializer,
    TransferenciaReadSerializer,
    StockSerializer,
    MovimientoStockSerializer,
    AjusteStockSerializer,
    StockAlertaSerializer,     # ✅ NUEVO
    StockConfigSerializer,     # ✅ NUEVO
)

from .services_stock import (
    aplicar_ingreso,
    confirmar_transferencia,
    confirmar_ajuste,
)


class StandardPagination(PageNumberPagination):
    page_size = 30
    page_size_query_param = "page_size"
    max_page_size = 200


# =========================================================
# ALMACENES
# =========================================================
class AlmacenViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Almacen.objects.filter(activo=True).order_by("tipo", "nombre")
    serializer_class = AlmacenSerializer
    pagination_class = None


# =========================================================
# INGRESOS
# =========================================================
class IngresoViewSet(viewsets.ModelViewSet):
    pagination_class = StandardPagination

    def get_queryset(self):
        qs = (
            Ingreso.objects.select_related("almacen_destino", "proveedor")
            .prefetch_related("detalles__producto__editorial")
            .order_by("-id")
        )

        search = self.request.query_params.get("search")
        proveedor = self.request.query_params.get("proveedor")
        almacen = self.request.query_params.get("almacen")

        if search:
            qs = qs.filter(
                Q(numero_documento__icontains=search)
                | Q(proveedor__nombre__icontains=search)
            )
        if proveedor:
            qs = qs.filter(proveedor_id=proveedor)
        if almacen:
            qs = qs.filter(almacen_destino_id=almacen)

        return qs

    def get_serializer_class(self):
        if self.action in ("create", "update", "partial_update"):
            return IngresoWriteSerializer
        return IngresoReadSerializer

    @action(detail=True, methods=["post"], url_path="procesar")
    def procesar(self, request, pk=None):
        ingreso = self.get_object()
        try:
            with transaction.atomic():
                aplicar_ingreso(ingreso)
            return Response({"detail": "Ingreso procesado correctamente."}, status=200)
        except Exception as e:
            return Response({"detail": str(e)}, status=400)


# =========================================================
# TRANSFERENCIAS
# =========================================================
class TransferenciaViewSet(viewsets.ModelViewSet):
    pagination_class = StandardPagination

    def get_queryset(self):
        qs = (
            Transferencia.objects.select_related("almacen_origen", "almacen_destino")
            .prefetch_related("detalles__producto__editorial")
            .order_by("-id")
        )

        search = self.request.query_params.get("search")
        estado = self.request.query_params.get("estado")
        origen = self.request.query_params.get("origen")
        destino = self.request.query_params.get("destino")

        if search:
            qs = qs.filter(numero_documento__icontains=search)
        if estado:
            qs = qs.filter(estado=estado)
        if origen:
            qs = qs.filter(almacen_origen_id=origen)
        if destino:
            qs = qs.filter(almacen_destino_id=destino)

        return qs

    def get_serializer_class(self):
        if self.action in ("create", "update", "partial_update"):
            return TransferenciaWriteSerializer
        return TransferenciaReadSerializer

    @action(detail=True, methods=["post"], url_path="confirmar")
    def confirmar(self, request, pk=None):
        trans = self.get_object()

        if trans.estado != EstadoTransferencia.BORRADOR:
            return Response({"detail": "Solo se puede confirmar una transferencia en BORRADOR."}, status=400)

        try:
            with transaction.atomic():
                confirmar_transferencia(trans)
            return Response({"detail": "Transferencia confirmada correctamente."}, status=200)
        except Exception as e:
            return Response({"detail": str(e)}, status=400)

    @action(detail=True, methods=["post"], url_path="anular")
    def anular(self, request, pk=None):
        trans = self.get_object()
        if trans.estado == EstadoTransferencia.CONFIRMADA:
            return Response({"detail": "No se puede anular una transferencia CONFIRMADA."}, status=400)

        trans.estado = EstadoTransferencia.ANULADA
        trans.save(update_fields=["estado"])
        return Response({"detail": "Transferencia anulada."}, status=200)


# =========================================================
# STOCK
# =========================================================
class StockViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = StockSerializer
    pagination_class = StandardPagination

    def get_queryset(self):
        qs = Stock.objects.select_related("almacen", "producto__editorial").order_by(
            "almacen__tipo", "producto__nombre"
        )

        almacen = self.request.query_params.get("almacen")
        editorial = self.request.query_params.get("editorial")
        search = self.request.query_params.get("search")

        if almacen:
            qs = qs.filter(almacen_id=almacen)
        if editorial:
            qs = qs.filter(producto__editorial_id=editorial)
        if search:
            qs = qs.filter(
                Q(producto__nombre__icontains=search)
                | Q(producto__codigo__icontains=search)
            )

        return qs


# =========================================================
# ✅ STOCK ALERTAS (quiebre de stock)
# GET /api/almacen/v2/stock-alertas/?almacen=1&editorial=2&solo=CRITICO|ATENCION
# =========================================================
class StockAlertViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = StockAlertaSerializer
    pagination_class = StandardPagination

    def get_queryset(self):
        qs = Stock.objects.select_related("almacen", "producto__editorial").all()

        almacen = self.request.query_params.get("almacen")
        editorial = self.request.query_params.get("editorial")
        search = self.request.query_params.get("search")
        solo = (self.request.query_params.get("solo") or "").upper()

        if almacen:
            qs = qs.filter(almacen_id=almacen)
        if editorial:
            qs = qs.filter(producto__editorial_id=editorial)
        if search:
            qs = qs.filter(
                Q(producto__nombre__icontains=search)
                | Q(producto__codigo__icontains=search)
            )

        # filtrar solo los que están por debajo de reposición o mínimo
        # - Critico: cantidad <= stock_minimo (si stock_minimo > 0)
        # - Atención: cantidad <= punto_reposicion (si punto_reposicion > 0)
        # Nota: esto filtra a nivel DB (más rápido)
        qs_alerta = qs.filter(
            Q(stock_minimo__gt=0, cantidad_actual__lte=models.F("stock_minimo"))
            | Q(punto_reposicion__gt=0, cantidad_actual__lte=models.F("punto_reposicion"))
        )

        # filtro opcional por nivel
        if solo == "CRITICO":
            qs_alerta = qs_alerta.filter(stock_minimo__gt=0, cantidad_actual__lte=models.F("stock_minimo"))
        elif solo == "ATENCION":
            qs_alerta = qs_alerta.filter(
                punto_reposicion__gt=0, cantidad_actual__lte=models.F("punto_reposicion")
            ).exclude(stock_minimo__gt=0, cantidad_actual__lte=models.F("stock_minimo"))

        return qs_alerta.order_by("almacen__tipo", "producto__nombre")


# =========================================================
# ✅ STOCK CONFIG (set mínimo y punto reposición)
# PATCH /api/almacen/v2/stock-config/<id>/
# =========================================================
class StockConfigViewSet(
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    viewsets.GenericViewSet,
):
    serializer_class = StockConfigSerializer
    pagination_class = StandardPagination

    def get_queryset(self):
        qs = Stock.objects.select_related("almacen", "producto__editorial").order_by(
            "almacen__tipo", "producto__nombre"
        )

        almacen = self.request.query_params.get("almacen")
        editorial = self.request.query_params.get("editorial")
        search = self.request.query_params.get("search")

        if almacen:
            qs = qs.filter(almacen_id=almacen)
        if editorial:
            qs = qs.filter(producto__editorial_id=editorial)
        if search:
            qs = qs.filter(
                Q(producto__nombre__icontains=search)
                | Q(producto__codigo__icontains=search)
            )

        return qs


# =========================================================
# KARDEX / MOVIMIENTOS
# =========================================================
class MovimientoStockViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = MovimientoStockSerializer
    pagination_class = StandardPagination

    def get_queryset(self):
        qs = MovimientoStock.objects.select_related("almacen", "producto__editorial").order_by("-fecha", "-id")

        almacen = self.request.query_params.get("almacen")
        producto = self.request.query_params.get("producto")
        tipo = self.request.query_params.get("tipo")
        search = self.request.query_params.get("search")

        if almacen:
            qs = qs.filter(almacen_id=almacen)
        if producto:
            qs = qs.filter(producto_id=producto)
        if tipo:
            qs = qs.filter(tipo=tipo)
        if search:
            qs = qs.filter(
                Q(numero_documento__icontains=search)
                | Q(producto__nombre__icontains=search)
            )

        return qs


# =========================================================
# AJUSTES DE STOCK (ERP)
# POST /api/almacen/v2/ajustes/
# =========================================================
class AjusteStockViewSet(viewsets.ViewSet):
    serializer_class = AjusteStockSerializer

    def create(self, request):
        ser = AjusteStockSerializer(data=request.data)
        ser.is_valid(raise_exception=True)

        data = ser.validated_data
        try:
            with transaction.atomic():
                confirmar_ajuste(
                    almacen_id=data["almacen_id"],
                    motivo=data["motivo"],
                    tipo_documento=data.get("tipo_documento", "OTRO"),
                    numero_documento=data.get("numero_documento", ""),
                    items=data["items"],
                )
            return Response({"detail": "Ajuste aplicado correctamente."}, status=200)
        except Exception as e:
            return Response({"detail": str(e)}, status=400)
